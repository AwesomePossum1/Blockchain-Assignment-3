# On-Chain Story Relay DApp

A decentralized application (DApp) built on Ethereum where users collaboratively write a continuous, on-chain story line by line. The contract enforces turn-based writing rules and allows chapters to be reset after reaching a designated line threshold.

**Author:** Usman Zaheer Qureshi  
**Course Assignment:** Blockchain Development  

---

## 🚀 Tech Stack & Tools
* **Smart Contract:** Solidity (`^0.8.20`)
* **Development & Compilation:** Remix IDE (EVM Version: `shanghai`/`paris`)
* **Local Blockchain:** Ganache Local (RPC: `http://127.0.0.1:7545`, Chain ID: `1337`)
* **Wallet & Provider:** MetaMask Browser Extension
* **Frontend Library:** Ethers.js v6 (`6.13.2`)
* **UI/UX:** HTML5, CSS3, JavaScript (Vanilla)

---

## 📁 Repository Folder Structure
```text
├── contracts/
│   └── OnChainStory.sol        # Solidity smart contract source code
├── migrations/
│   └── 2_deploy_contract.js    # Truffle/Ganache deployment migration script
├── src/
│   ├── index.html              # Frontend user interface
│   └── script.js               # Ethers.js logic and wallet integration
├── truffle-config.js           # Network and compiler configuration
├── README.md                   # Project documentation
└── screenshots/                # Evidence of compilation, deployment, and UI interaction