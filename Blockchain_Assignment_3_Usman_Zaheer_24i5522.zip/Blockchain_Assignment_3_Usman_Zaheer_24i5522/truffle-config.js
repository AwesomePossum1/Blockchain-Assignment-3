/**
 * Use this file to configure your truffle project.
 */

module.exports = {
  networks: {
    development: {
      host: "127.0.0.1",     // Localhost
      port: 7545,            // Standard Ganache GUI port
      network_id: "*",       // Any network
    },
    advanced: {
      port: 8777,            
      network_id: 1342,      
      gas: 8500000,          
      gasPrice: 20000000000, 
      websocket: true        
    },
  },

  mocha: {
    // timeout: 100000
  },

  compilers: {
    solc: {
      version: "0.8.21",     
      settings: {
        evmVersion: "paris"  // Fixes the PUSH0 / invalid opcode deployment error
      }
    }
  }
};