const YourContractName = artifacts.require("OnChainStory");
module.exports = function (deployer) {
  deployer.deploy(YourContractName);
};