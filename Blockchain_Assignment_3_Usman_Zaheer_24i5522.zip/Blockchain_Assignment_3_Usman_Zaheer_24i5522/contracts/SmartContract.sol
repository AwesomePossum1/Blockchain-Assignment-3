// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract OnChainStory {
    string public story;
    address public lastAuthor;
    uint256 public lineCount;

    // 1. WRITE FUNCTION: Add the next line to the story
    function addLine(string calldata _newLine) external {
        require(msg.sender != lastAuthor, "Wait your turn! Someone else must write next.");
        
        // Appends a space and the new line to the existing story
        story = string.concat(story, " ", _newLine);
        lastAuthor = msg.sender;
        lineCount++;
    }

    // 2. WRITE FUNCTION: Clear the story (only possible after 10 lines are written)
    function startNewChapter() external {
        require(lineCount >= 10, "A chapter needs at least 10 lines before resetting!");
        
        story = "";
        lineCount = 0;
        lastAuthor = address(0);
    }

    // 3. READ FUNCTION: Read the entire story so far
    function readStory() external view returns (string memory) {
        return story;
    }

    // 4. READ FUNCTION: Check if a specific wallet is allowed to write next
    function canWriteNext(address _writer) external view returns (bool) {
        return _writer != lastAuthor;
    }
}