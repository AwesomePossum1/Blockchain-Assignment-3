const contractAddress = "0x16B5a9EfbB74D3883d369b96d474085Af29e46d6"; // Update if you deploy a fresh one via Remix

const contractABI = [
  {
    "inputs": [],
    "name": "lastAuthor",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "lineCount",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "story",
    "outputs": [{ "internalType": "string", "name": "", "type": "string" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "string", "name": "_newLine", "type": "string" }],
    "name": "addLine",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "startNewChapter",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "readStory",
    "outputs": [{ "internalType": "string", "name": "", "type": "string" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "address", "name": "_writer", "type": "address" }],
    "name": "canWriteNext",
    "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }],
    "stateMutability": "view",
    "type": "function"
  }
];

let provider, signer, contract;

async function connectWallet() {
    if (window.ethereum) {
        try {
            // Automatically switch/add Ganache Local (Chain ID: 1337 / 0x539)
            try {
                await window.ethereum.request({
                    method: 'wallet_switchEthereumChain',
                    params: [{ chainId: '0x539' }],
                });
            } catch (switchError) {
                if (switchError.code === 4902) {
                    await window.ethereum.request({
                        method: 'wallet_addEthereumChain',
                        params: [{
                            chainId: '0x539',
                            chainName: 'Ganache Local',
                            rpcUrls: ['http://127.0.0.1:7545'],
                            nativeCurrency: { name: 'ETH', symbol: 'ETH', decimals: 18 }
                        }]
                    });
                }
            }

            provider = new ethers.BrowserProvider(window.ethereum);
            await provider.send("eth_requestAccounts", []);
            signer = await provider.getSigner();
            const address = await signer.getAddress();
            
            contract = new ethers.Contract(contractAddress, contractABI, signer);
            
            document.getElementById("walletStatus").innerText = "Connected: " + address;
            fetchStory();
        } catch (error) {
            console.error(error);
            alert("Connection failed!");
        }
    } else {
        alert("Please install MetaMask!");
    }
}

async function fetchStory() {
    try {
        let readContract = contract;
        if (!readContract) {
            let currentProvider = provider;
            if (!currentProvider && window.ethereum) {
                currentProvider = new ethers.BrowserProvider(window.ethereum);
            } else if (!currentProvider) {
                currentProvider = new ethers.JsonRpcProvider("http://127.0.0.1:7545");
            }
            readContract = new ethers.Contract(contractAddress, contractABI, currentProvider);
        }
        const storyText = await readContract.readStory();
        document.getElementById("storyDisplay").innerText = storyText || "(The story is empty)";
    } catch (error) {
        console.error("Error fetching story:", error);
        document.getElementById("storyDisplay").innerText = "(Error loading story - check console)";
    }
}

async function addLine() {
    if (!contract) { alert("Please connect wallet first!"); return; }
    const lineText = document.getElementById("nextLineInput").value;
    if (!lineText) { alert("Please enter text!"); return; }

    try {
        const tx = await contract.addLine(lineText);
        alert("Transaction sent! Waiting for confirmation...");
        await tx.wait();
        alert("Line added successfully!");
        document.getElementById("nextLineInput").value = "";
        fetchStory();
    } catch (error) {
        console.error(error);
        alert("Error: " + (error.reason || error.message));
    }
}

async function startNewChapter() {
    if (!contract) { alert("Please connect wallet first!"); return; }
    try {
        const tx = await contract.startNewChapter();
        alert("Transaction sent! Waiting for confirmation...");
        await tx.wait();
        alert("New chapter started!");
        fetchStory();
    } catch (error) {
        console.error(error);
        alert("Error: " + (error.reason || error.message));
    }
}

window.onload = fetchStory;